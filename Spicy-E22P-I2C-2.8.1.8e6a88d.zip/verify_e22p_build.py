import hashlib
import json
import pathlib
import struct
import subprocess

root = pathlib.Path(__file__).resolve().parent
build = root / 'firmware-build/.pio/build/spicy_e22p_i2c'
uf2 = build / 'firmware-spicy_e22p_i2c-2.8.1.8e6a88d.uf2'
elf = uf2.with_suffix('.elf')
data = uf2.read_bytes()
assert len(data) % 512 == 0
blocks = {}
addresses = set()
for offset in range(0, len(data), 512):
    block = data[offset:offset + 512]
    magic0, magic1, flags, addr, size, number, total, family = struct.unpack_from('<8I', block)
    assert magic0 == 0x0A324655 and magic1 == 0x9E5D5157
    assert struct.unpack_from('<I', block, 508)[0] == 0x0AB16F30
    assert flags & 0x2000 and not flags & 1
    assert family == 0xADA52840 and size == 256
    assert total == len(data) // 512
    assert number not in blocks and addr not in addresses
    assert 0x27000 <= addr and addr + size <= 0xEA000
    blocks[number] = (addr, block[32:32+size])
    addresses.add(addr)
assert set(blocks) == set(range(len(blocks)))
raw = b''.join(payload for addr, payload in sorted(blocks.values()))
assert b'2.8.1.8e6a88d\x00' in raw
assert b'spicy_e22p_i2c\x00' in raw
tool = root / '.platformio/packages/toolchain-gccarmnoneeabi/bin/arm-none-eabi-objdump.exe'
disassembly = subprocess.check_output([str(tool), '-d', '--disassemble=_Z11initVariantv', str(elf)], text=True)
(root / 'e22p-initVariant.txt').write_text(disassembly)
assert 'r0, #5' in disassembly and 'r1, #1' in disassembly
assert 'pinMode' in disassembly and 'digitalWrite' in disassembly
report = {
    'artifact': uf2.name,
    'sha256': hashlib.sha256(data).hexdigest(),
    'bytes': len(data),
    'blocks': len(blocks),
    'family': '0xADA52840 (nRF52840)',
    'address_min': hex(min(addresses)),
    'address_end': hex(max(addr + len(payload) for addr, payload in blocks.values())),
    'embedded_version': '2.8.1.8e6a88d',
    'embedded_environment': 'spicy_e22p_i2c',
    'hardware_runtime_tested': False,
}
(root / 'e22p-verification.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
